# __init__.py

__version__ = '1.2.6'
VERSION = tuple(map(int, __version__.split('.')))

